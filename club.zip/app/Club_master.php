<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Club_master extends Model
{
    protected $primaryKey = 'club_id';
}
