<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sports_master extends Model
{
    protected $primaryKey = 'sports_id';
}
